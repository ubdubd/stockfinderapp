package com.stockfinder.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_CAPTURE = 1002;
    private static final int CAMERA_PERMISSION = 1003;
    private Uri cameraUri;
    private long downloadId = -1;
    private BroadcastReceiver downloadReceiver;

    // Update checker looks at this repo's latest GitHub Release.
    private static final String UPDATE_API_URL = "https://api.github.com/repos/ubdubd/StockFinderApp/releases/latest";
    private static final String UPDATE_ASSET_NAME = "StockFinder.apk";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                if (params.isCaptureEnabled()) startCamera();
                else {
                    String[] acc = params.getAcceptTypes();
                    boolean img = acc != null && acc.length > 0 && acc[0] != null && acc[0].startsWith("image/");
                    openPicker(img ? "image/*" : "*/*");
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new ShareBridge(this), "AndroidShare");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#154D44"));
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Keep the page below the status bar even if the system draws edge-to-edge.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
        checkForUpdate();
    }

    private void openPicker() { openPicker("*/*"); }

    private void openPicker(String mime) {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType(mime);
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            startActivityForResult(pick, FILE_CHOOSER);
        } catch (Exception e) {
            if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        }
    }

    private void startCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File photo = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_CAPTURE);
        } catch (Exception e) {
            openPicker();   // no camera app -> let the user pick a photo instead
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else openPicker();
        }
    }

    private void checkForUpdate() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(UPDATE_API_URL);
                c = (HttpURLConnection) url.openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                if (c.getResponseCode() != 200) return;
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                JSONObject obj = new JSONObject(sb.toString());
                String tag = obj.optString("tag_name", "");
                if (!tag.startsWith("v")) return;
                int remoteCode = Integer.parseInt(tag.substring(1).replaceAll("\\..*", ""));
                int localCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
                String apkUrl = "";
                for (int i = 0; i < obj.getJSONArray("assets").length(); i++) {
                    JSONObject a = obj.getJSONArray("assets").getJSONObject(i);
                    if (a.optString("name").equals(UPDATE_ASSET_NAME)) { apkUrl = a.optString("browser_download_url"); break; }
                }
                if (remoteCode > localCode && !apkUrl.isEmpty()) {
                    final String finalUrl = apkUrl;
                    final int installedCode = localCode;
                    runOnUiThread(() -> showUpdateDialog(finalUrl, tag, installedCode));
                }
            } catch (Exception ignored) { }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }

    private void showUpdateDialog(String apkUrl, String version, int installedCode) {
        new AlertDialog.Builder(this)
            .setTitle("Stock Finder Update Available")
            .setMessage("New version " + version + " is available (installed: v" + installedCode + "). Update now?")
            .setNegativeButton("Later", null)
            .setPositiveButton("Update", (d, w) -> downloadUpdate(apkUrl))
            .show();
    }

    private void downloadUpdate(String apkUrl) {
        try {
            // DownloadManager will not overwrite an existing file. A leftover
            // StockFinder.apk from an earlier update made every later update
            // fail silently (or reinstall the old one) -> endless update popup.
            File apkDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (apkDir != null) { File oldApk = new File(apkDir, "StockFinder.apk"); if (oldApk.exists()) oldApk.delete(); }
            android.widget.Toast.makeText(this, "Downloading update…", android.widget.Toast.LENGTH_LONG).show();
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(apkUrl);
            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.setTitle("Stock Finder update");
            req.setDescription("Downloading latest Stock Finder APK");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "StockFinder.apk");
            downloadId = dm.enqueue(req);
            downloadReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                    if (id != downloadId) return;
                    try {
                        DownloadManager.Query q = new DownloadManager.Query().setFilterById(downloadId);
                        android.database.Cursor cur = dm.query(q);
                        if (cur != null && cur.moveToFirst()) {
                            int status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                            int reason = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                            cur.close();
                            if (status == DownloadManager.STATUS_SUCCESSFUL) installDownloadedApk();
                            else new AlertDialog.Builder(MainActivity.this).setTitle("Update download failed").setMessage("Could not download the update (error " + reason + "). Please try again.").setPositiveButton("OK", null).show();
                        }
                    } finally { unregisterReceiver(this); downloadReceiver = null; }
                }
            };
            ContextCompat.registerReceiver(this, downloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Update failed").setMessage("Could not download the update.").setPositiveButton("OK", null).show();
        }
    }

    private void installDownloadedApk() {
        java.io.File apk = new java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "StockFinder.apk");
        if (!apk.exists()) return;
        if (android.os.Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            new AlertDialog.Builder(this).setTitle("Allow installation").setMessage("Allow Stock Finder to install updates, then tap the update again.").setPositiveButton("OK", null).show();
            return;
        }
        Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_CAPTURE && fileCallback != null) {
            Uri[] shot = (resultCode == RESULT_OK && cameraUri != null) ? new Uri[]{cameraUri} : null;
            fileCallback.onReceiveValue(shot); fileCallback = null;
        } else if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null && data.getClipData().getItemCount() > 0) result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
                else if (data.getData() != null) result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    // The web app is a single page with no real navigation history, so
    // webView.canGoBack() is always false and back used to close the app
    // immediately. Ask the page's own JS (handleAndroidBack) to close any
    // open overlay or clear the search back to the home screen first; only
    // when it reports there's nothing left to unwind do we actually exit.
    @Override public void onBackPressed() {
        webView.evaluateJavascript(
            "(function(){ try { return !!(window.handleAndroidBack && window.handleAndroidBack()); } catch(e){ return false; } })()",
            value -> runOnUiThread(() -> {
                if (!"true".equals(value)) {
                    if (webView.canGoBack()) webView.goBack();
                    else MainActivity.this.finish();
                }
            })
        );
    }
}
