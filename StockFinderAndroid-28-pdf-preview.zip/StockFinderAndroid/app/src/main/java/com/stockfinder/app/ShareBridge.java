package com.stockfinder.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/** Native helpers the HTML calls as window.AndroidShare.* (WebView has no Web Share / file download). */
public class ShareBridge {
    private final Activity activity;

    ShareBridge(Activity activity) { this.activity = activity; }

    private static String cleanName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "").trim();
        return n.isEmpty() ? fallback : n;
    }

    private void toast(final String msg) {
        activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    private File writeToCache(String folder, String name, byte[] bytes) throws Exception {
        File dir = new File(activity.getCacheDir(), folder);
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();   // keep cache small
        File out = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(out);
        try { fos.write(bytes); } finally { fos.close(); }
        return out;
    }

    private void openShareSheet(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, "Share");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(chooser);
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Send a file straight to WhatsApp (no chooser). Falls back to the
     *  general share sheet if WhatsApp is not installed. */
    private void openWhatsAppDirect(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.setPackage("com.whatsapp");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(send);
            } catch (ActivityNotFoundException e) {
                // WhatsApp not installed — fall back to the normal share sheet.
                openShareSheet(uri, mime, text);
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open WhatsApp", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Share a PDF (base64) directly to WhatsApp. Called from the web app's
     *  "PDF" and "WhatsApp" buttons — window.AndroidShare.sharePdfToWhatsApp(...) */
    @JavascriptInterface
    public void sharePdfToWhatsApp(String filename, String base64Pdf, String text) {
        try {
            String name = cleanName(filename, "Stock.pdf");
            byte[] bytes = Base64.decode(base64Pdf, Base64.DEFAULT);
            File f = writeToCache("shared", name, bytes);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openWhatsAppDirect(uri, "application/pdf", text);
        } catch (Exception e) {
            toast("Could not share PDF");
        }
    }

    /** Share plain text (no file) to WhatsApp. Used by the web app's
     *  "Share to WhatsApp" button on the Low Stock Notes list —
     *  window.AndroidShare.shareTextToWhatsApp(text). Always goes through
     *  the normal Android share sheet (no forced package) so a phone with
     *  both WhatsApp and WhatsApp Business installed lets the user pick
     *  which one, instead of silently locking to one of them. */
    @JavascriptInterface
    public void shareTextToWhatsApp(String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                activity.startActivity(Intent.createChooser(send, "Share to"));
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Share one JPEG image with a text caption (the Low Stock Notes "with photos"
     *  share) — window.AndroidShare.shareImageToWhatsApp(filename, base64Jpg, caption).
     *  Goes through the normal share sheet so WhatsApp / WhatsApp Business can be picked. */
    @JavascriptInterface
    public void shareImageToWhatsApp(String filename, String base64Jpg, String caption) {
        try {
            String name = cleanName(filename, "LowStock.jpg");
            byte[] bytes = Base64.decode(base64Jpg, Base64.DEFAULT);
            File f = writeToCache("shared", name, bytes);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openShareSheet(uri, "image/jpeg", caption);
        } catch (Exception e) {
            toast("Could not share image");
        }
    }

    /** Share several JPEG images at once (Low Stock Notes: one image per photo item) —
     *  window.AndroidShare.shareImagesToWhatsApp("b64one|b64two|..."). Normal share sheet,
     *  so WhatsApp / WhatsApp Business can be picked. */
    @JavascriptInterface
    public void shareImagesToWhatsApp(String base64Joined) {
        try {
            String[] data = base64Joined.split("\\|");
            File dir = new File(activity.getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            final ArrayList<Uri> uris = new ArrayList<>();
            for (int i = 0; i < data.length; i++) {
                if (data[i].isEmpty()) continue;
                byte[] bytes = Base64.decode(data[i], Base64.DEFAULT);
                File out = new File(dir, "LowStock_" + (i + 1) + ".jpg");
                FileOutputStream fos = new FileOutputStream(out);
                try { fos.write(bytes); } finally { fos.close(); }
                uris.add(FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", out));
            }
            if (uris.isEmpty()) { toast("No images to share"); return; }
            if (uris.size() == 1) { openShareSheet(uris.get(0), "image/jpeg", null); return; }
            activity.runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    send.setType("image/jpeg");
                    send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    ClipData cd = ClipData.newRawUri("", uris.get(0));
                    for (int i = 1; i < uris.size(); i++) cd.addItem(new ClipData.Item(uris.get(i)));
                    send.setClipData(cd);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Share");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(chooser);
                } catch (Exception e) {
                    Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            toast("Could not share images");
        }
    }

    /** Bulk share: many JPEGs in ONE share, each with its OWN caption (WhatsApp reads the
     *  EXTRA_TEXT list as per-image captions) —
     *  window.AndroidShare.shareImagesWithCaptions("b64one|b64two|...", "cap1\u001Fcap2\u001F...").
     *  Normal share sheet, so WhatsApp / WhatsApp Business can be picked. */
    @JavascriptInterface
    public void shareImagesWithCaptions(String base64Joined, String captionsJoined) {
        try {
            String[] data = base64Joined.split("\\|");
            String[] caps = captionsJoined == null ? new String[0] : captionsJoined.split("\u001F", -1);
            File dir = new File(activity.getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            final ArrayList<Uri> uris = new ArrayList<>();
            final ArrayList<CharSequence> texts = new ArrayList<>();
            for (int i = 0; i < data.length; i++) {
                if (data[i].isEmpty()) continue;
                byte[] bytes = Base64.decode(data[i], Base64.DEFAULT);
                File out = new File(dir, "LowStock_" + (i + 1) + ".jpg");
                FileOutputStream fos = new FileOutputStream(out);
                try { fos.write(bytes); } finally { fos.close(); }
                uris.add(FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", out));
                texts.add(i < caps.length ? caps[i] : "");
            }
            if (uris.isEmpty()) { toast("No images to share"); return; }
            activity.runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    send.setType("image/jpeg");
                    send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    send.putCharSequenceArrayListExtra(Intent.EXTRA_TEXT, texts);
                    ClipData cd = ClipData.newRawUri("", uris.get(0));
                    for (int i = 1; i < uris.size(); i++) cd.addItem(new ClipData.Item(uris.get(i)));
                    send.setClipData(cd);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Share");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(chooser);
                } catch (Exception e) {
                    Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            toast("Could not share images");
        }
    }

    /** PDF + a page-1 preview photo in ONE share (chat shows the photo, then the PDF file) —
     *  window.AndroidShare.sharePdfWithPreview(pdfName, base64Pdf, jpgName, base64Jpg, caption).
     *  Normal share sheet, so WhatsApp / WhatsApp Business can be picked. */
    @JavascriptInterface
    public void sharePdfWithPreview(String pdfName, String base64Pdf, String jpgName, String base64Jpg, String caption) {
        try {
            File dir = new File(activity.getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File jpg = new File(dir, cleanName(jpgName, "LowStock_page1.jpg"));
            FileOutputStream f1 = new FileOutputStream(jpg);
            try { f1.write(Base64.decode(base64Jpg, Base64.DEFAULT)); } finally { f1.close(); }
            File pdf = new File(dir, cleanName(pdfName, "LowStock.pdf"));
            FileOutputStream f2 = new FileOutputStream(pdf);
            try { f2.write(Base64.decode(base64Pdf, Base64.DEFAULT)); } finally { f2.close(); }
            final ArrayList<Uri> uris = new ArrayList<>();
            uris.add(FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", jpg));
            uris.add(FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", pdf));
            final ArrayList<CharSequence> texts = new ArrayList<>();
            texts.add(caption == null ? "" : caption);
            texts.add("");
            activity.runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    send.setType("*/*");
                    send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    send.putCharSequenceArrayListExtra(Intent.EXTRA_TEXT, texts);
                    ClipData cd = ClipData.newRawUri("", uris.get(0));
                    cd.addItem(new ClipData.Item(uris.get(1)));
                    send.setClipData(cd);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Share");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    activity.startActivity(chooser);
                } catch (Exception e) {
                    Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            toast("Could not share PDF");
        }
    }

    /** Share a PDF with a text caption through the normal share sheet (so WhatsApp or
     *  WhatsApp Business can be picked) — window.AndroidShare.sharePdfFile(...).
     *  Used by Low Stock Notes "Share as PDF". */
    @JavascriptInterface
    public void sharePdfFile(String filename, String base64Pdf, String text) {
        try {
            String name = cleanName(filename, "LowStock.pdf");
            byte[] bytes = Base64.decode(base64Pdf, Base64.DEFAULT);
            File f = writeToCache("shared", name, bytes);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openShareSheet(uri, "application/pdf", text);
        } catch (Exception e) {
            toast("Could not share PDF");
        }
    }

    /** Save an arbitrary file (Excel, PDF, etc., as base64) into the device's
     *  public Downloads folder. Called from the web app's "Download Excel" /
     *  "Download PDF" buttons — window.AndroidShare.saveFileToDownloads(...).
     *  WebView has no built-in handling for an <a download> click (that only
     *  works if the app registers a DownloadListener, which this app does
     *  not), so those clicks otherwise do nothing at all on a phone. */
    @JavascriptInterface
    public void saveFileToDownloads(String filename, String base64Data, String mime) {
        try {
            String name = cleanName(filename, "StockFinder_file");
            byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
            String mimeType = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, name);
                FileOutputStream fos = new FileOutputStream(out);
                try { fos.write(bytes); } finally { fos.close(); }
            }
            toast("Saved to Downloads: " + name);
        } catch (Exception e) {
            toast("Could not save " + filename);
        }
    }

    /** Save a photo (data URL) to Pictures/StockFinder. */
    @JavascriptInterface
    public void savePhoto(String filename, String dataUrl) {
        try {
            String name = cleanName(filename, "photo.jpg");
            byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/StockFinder");
                Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
            } else {
                File f = writeToCache("shared", name, bytes);
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                openShareSheet(uri, "image/jpeg", null);
            }
        } catch (Exception e) {
            toast("Could not save photo");
        }
    }
}
